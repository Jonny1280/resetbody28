# Многошаговая форма

Это простая и адаптивная многошаговая форма с прогресс-баром, поддержкой тёмной темы и интеграцией с Stripe.

## Особенности

- Пошаговое заполнение формы
- Прогресс-бар
- Интерактивный ползунок веса
- Поддержка тёмного режима
- Интеграция с Google Apps Script (для отправки данных)
- Stripe Buy Button

## Установка

1. Скачайте репозиторий или клонируйте:
   ```bash
   git clone https://github.com/yourusername/multistep-form.git
   ```
2. Откройте `index.html` в браузере.

## Демо

Доступно на GitHub Pages:
👉 [https://yourusername.github.io/multistep-form](https://yourusername.github.io/multistep-form)

## Скрипт отправки данных

Замените URL в `main.js`:
```js
const scriptURL = 'https://script.googleusercontent.com/macros/your-script-url';
```

## Лицензия

MIT
