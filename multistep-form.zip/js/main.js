let currentStep = 1;
const steps = document.querySelectorAll(".step");
const totalSteps = steps.length;

function showStep(n) {
  steps.forEach((step, index) => {
    step.classList.toggle("active", index === n);
  });
  updateProgress();
  toggleButtons(n);
}

function nextPrev(n) {
  if (n === 1 && !validateForm()) return false;

  currentStep += n;

  let name, age, weight, goal, activity, email;

  if (currentStep === totalSteps - 1) {
    name = document.forms[0]["name"].value;
    age = document.forms[0]["age"].value;
    weight = document.forms[0]["weight"].value;
    goal = document.forms[0]["goal"].value;
    activity = document.forms[0]["activity"].value;
    email = document.forms[0]["email"].value;

    const userData = { name, age, weight, goal, activity, email };
    sendDataToSheet(userData);

    document.getElementById("loader").style.display = "block";
    document.getElementById("finalResult").innerHTML = "Обработка данных...";
  }

  setTimeout(() => {
    if (currentStep === totalSteps - 1) {
      document.getElementById("loader").style.display = "none";
      document.getElementById("finalResult").innerHTML = `
        Спасибо, ${name}!<br/>
        Ваш вес: ${weight} кг<br/>
        Цель: ${goal}<br/>
        Активность: ${activity}
      `;
    }
    showStep(currentStep - 1);
  }, 1500);
}

function validateForm() {
  const inputs = document.forms[0].querySelectorAll(":required");
  for (let i = 0; i < inputs.length; i++) {
    if (!inputs[i].value.trim()) {
      alert("Пожалуйста, заполните все поля.");
      return false;
    }
  }
  return true;
}

function updateProgress() {
  const percent = (currentStep / totalSteps) * 100;
  document.getElementById("progress").style.width = percent + "%";
}

function toggleButtons(step) {
  document.getElementById("prevBtn").style.display = step === 0 ? "none" : "inline-block";
  document.getElementById("nextBtn").innerText = step === totalSteps - 1 ? "Завершить" : "Далее";
}

async function sendDataToSheet(data) {
  const scriptURL = 'https://script.googleusercontent.com/macros/your-script-url'; // Замените на ваш URL
  try {
    const response = await fetch(scriptURL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    console.log('Данные успешно отправлены');
  } catch (error) {
    console.error('Ошибка:', error.message);
  }
}

showStep(0);
